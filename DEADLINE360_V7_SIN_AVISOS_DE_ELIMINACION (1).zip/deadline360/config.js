// CONFIGURACIÓN DE DEADLINE 360
// Cambia estos valores antes de publicar la aplicación. No pongas secretos aquí.
window.D360_CONFIG = {
  // Escribe aquí el correo que tendrá acceso de administrador sin elegir plan ni pagar.
  adminEmail: "PON_AQUI_TU_CORREO_ADMIN",
  adminName: "Administrador",
  // Número Bizum receptor de tu negocio (formato internacional o nacional).
  bizumPhone: "PON_AQUI_TU_NUMERO_BIZUM"
};
