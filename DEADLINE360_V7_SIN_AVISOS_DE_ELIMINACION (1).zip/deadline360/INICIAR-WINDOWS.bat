@echo off
cd /d "%~dp0"
start "DEADLINE 360 Server" cmd /k py -m http.server 8000
 timeout /t 2 >nul
start "" http://localhost:8000
