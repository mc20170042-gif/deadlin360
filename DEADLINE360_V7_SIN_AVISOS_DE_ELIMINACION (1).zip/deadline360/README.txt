DEADLINE 360 ENTERPRISE — VERSIÓN 7 (ACTIVIDAD RECIENTE SIN REGISTROS DE ELIMINACIÓN)

INICIO
1. Descomprime el ZIP.
2. Abre Terminal en la carpeta deadline360 y ejecuta: python3 -m http.server 8000
   En Windows también puedes ejecutar INICIAR-WINDOWS.bat.
3. Abre http://localhost:8000 en Chrome.

CONFIGURAR TU CUENTA DE ADMINISTRADOR Y BIZUM
1. Antes de usarla, abre config.js con un editor de texto.
2. Sustituye PON_AQUI_TU_CORREO_ADMIN por el correo que usarás como administrador. Ese correo entra directamente con acceso completo y no ve la selección de planes ni el pago.
3. Sustituye PON_AQUI_TU_NUMERO_BIZUM por el número Bizum receptor de tu negocio.
4. Guarda config.js y vuelve a cargar la aplicación.

PLANES
- Gratuito: 0 €/mes. Hasta 10 tareas abiertas y funciones básicas.
- Premium: 3,75 €/mes. Tareas ilimitadas, calendario, documentos, copias y exportación.
- Profesional: 5,95 €/mes. Todo Premium, informes avanzados y seguimiento por áreas.
- Administrador: acceso completo sin pago para el correo configurado en config.js.

BIZUM — LIMITACIÓN IMPORTANTE
La pantalla muestra el número Bizum, importe y concepto. «He enviado el Bizum» crea una solicitud pendiente, NO confirma el ingreso ni cobra automáticamente. Esta versión es una demostración local: no tiene conexión bancaria ni servidor de verificación, y no desbloquea automáticamente el plan de pago. Para cobrar y activar suscripciones reales se necesita un backend seguro, verificación de pagos y un acuerdo/solución Bizum para comercios con la entidad bancaria. No publiques un número personal sin asegurarte de que puede recibir pagos comerciales.

SEGURIDAD Y CUENTAS
El acceso de administrador por correo en esta demo no es autenticación segura: cualquiera que escriba ese correo podría hacerse pasar por el administrador. No uses esta versión para datos sensibles ni para cobrar clientes reales. En producción se necesita login con contraseña/MFA y roles verificados en servidor. Los perfiles y tareas siguen guardándose localmente en este navegador.

AVISOS
Los avisos del navegador necesitan permiso. Una web estática no garantiza vibración o avisos con la app cerrada; para ello se requiere servidor y notificaciones push.


CAMBIO V7 — ACTIVIDAD RECIENTE
- Al eliminar una tarea, no se crea una entrada «Eliminado» en Actividad reciente.
- Al abrir la aplicación, también se filtran los registros «Eliminado» antiguos que ya estuvieran guardados en este navegador.
- La eliminación sigue quitando la tarea de la lista y muestra únicamente una confirmación temporal.
